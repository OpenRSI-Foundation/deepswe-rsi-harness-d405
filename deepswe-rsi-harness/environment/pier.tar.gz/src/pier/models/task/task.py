import re
from pathlib import Path

from pier.models.task.config import TaskConfig
from pier.models.task.paths import TaskPaths
from pier.models.task.verifier_mode import resolve_effective_verifier_env_config

# Matches canary lines: HTML comments (<!-- ...canary... -->) or hash comments (# ...canary...)
_CANARY_LINE_RE = re.compile(r"^(<!--.*canary.*-->|#.*canary.*)$", re.IGNORECASE)


def strip_canary(text: str) -> str:
    """Strip canary marker lines from the beginning of instruction text.

    Canary strings are data-provenance markers embedded in benchmark files to prevent
    training-data contamination. They should not be shown to agents. This function
    removes leading lines that match common canary comment formats (HTML comments or
    hash comments containing the word "canary"), plus any blank lines that follow.
    """
    lines = text.split("\n")
    idx = 0
    # Remove leading canary comment lines
    while idx < len(lines) and _CANARY_LINE_RE.match(lines[idx].strip()):
        idx += 1
    # Remove any blank lines immediately after the canary block
    while idx < len(lines) and lines[idx].strip() == "":
        idx += 1
    return "\n".join(lines[idx:])


class Task:
    """
    Represents a task with the following directory structure:

    ├── instruction.md
    ├── task.toml
    ├── environment/
    │   ├── [docker-compose.yaml | Dockerfile | singularity-compose.yaml | etc.]
    │   └── ...
    ├── solution/         # copied to container @ /solution by OracleAgent
    │   ├── solve.{sh,ps1,cmd,bat}
    │   └── ...
    └── tests/            # copied to container @ /tests by Evaluator
        ├── test.{sh,ps1,cmd,bat}
        └── ...
    """

    def __init__(self, task_dir: Path | str):
        """
        Initialize a Task from a directory path.

        Args:
            task_dir: Path to the task directory
        """
        self._task_dir = Path(task_dir).resolve()
        self.paths = TaskPaths(self._task_dir)
        self.config = TaskConfig.model_validate_toml(self.paths.config_path.read_text())
        if self.config.task is not None:
            self.name = self.config.task.name
        else:
            self.name = self.paths.task_dir.name

        if self.has_steps:
            self._validate_steps()
            self.instruction = ""
        else:
            self.instruction = strip_canary(self.paths.instruction_path.read_text())

    @property
    def has_steps(self) -> bool:
        return bool(self.config.steps)

    def step_instruction(self, step_name: str) -> str:
        path = self.paths.step_instruction_path(step_name)
        return strip_canary(path.read_text())

    def _validate_steps(self) -> None:
        task_os = self.config.environment.os
        for step_cfg in self.config.steps or []:
            step_dir = self.paths.step_dir(step_cfg.name)
            if not step_dir.exists():
                raise FileNotFoundError(f"Step directory not found: {step_dir}")
            instruction = self.paths.step_instruction_path(step_cfg.name)
            if not instruction.exists():
                raise FileNotFoundError(f"Step instruction not found: {instruction}")

            # Separate-verifier steps build their verification environment from
            # tests/, so the test script may live only in the verifier image.
            verifier_env = resolve_effective_verifier_env_config(self.config, step_cfg)
            if verifier_env is not None:
                continue

            step_test = self.paths.discovered_step_test_path_for(step_cfg.name, task_os)
            shared_test = self.paths.discovered_test_path_for(task_os)
            if step_test is None and shared_test is None:
                expected_step_test = self.paths.step_test_path_for(
                    step_cfg.name, task_os
                )
                expected_shared_test = self.paths.test_path_for(task_os)
                raise FileNotFoundError(
                    f"No {task_os.value} test script for step '{step_cfg.name}': "
                    f"neither {expected_step_test} nor {expected_shared_test} exist"
                )

    @property
    def checksum(self) -> str:
        """Generate a deterministic hash for the task based on its entire directory content."""
        from dirhash import dirhash

        return dirhash(self._task_dir, "sha256")

    @property
    def task_dir(self) -> Path:
        """Public accessor for the task directory."""
        return self._task_dir
