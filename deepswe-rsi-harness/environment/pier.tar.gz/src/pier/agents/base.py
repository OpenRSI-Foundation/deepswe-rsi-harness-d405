import logging
from abc import ABC, abstractmethod
from pathlib import Path

from pier.environments.base import BaseEnvironment
from pier.models.agent.context import AgentContext
from pier.models.agent.install import AgentInstallSpec
from pier.models.agent.network import NetworkAllowlist
from pier.models.task.config import MCPServerConfig
from pier.models.trial.result import AgentInfo, ModelInfo
from pier.utils.logger import logger as global_logger


class BaseAgent(ABC):
    logs_dir: Path
    model_name: str | None
    logger: logging.Logger

    # Whether agent supports Pier's trajectory format (ATIF)
    # Subclasses should override this class variable to indicate ATIF support
    SUPPORTS_ATIF: bool = False

    # Whether agent supports Windows container tasks.
    # Agents that only use Linux tools (bash, apt-get, tmux, etc.) in setup()
    # should keep the default False.  The trial runner checks this flag before
    # calling setup() and fails fast with a clear error on mismatch.
    SUPPORTS_WINDOWS: bool = False

    def __init__(
        self,
        logs_dir: Path,
        model_name: str | None = None,
        logger: logging.Logger | None = None,
        mcp_servers: list[MCPServerConfig]
        | None = None,  # MCP servers from task config; see setup()/run() for usage
        skills_dir: str | None = None,  # Skills directory path in the environment
        *args,
        **kwargs,
    ):
        self.logs_dir = logs_dir
        self.model_name = model_name
        self.logger = (logger or global_logger).getChild(__name__)
        self.mcp_servers = mcp_servers or []
        self.skills_dir = skills_dir

        self._init_model_info()

    def _init_model_info(self):
        self._parsed_model_provider = None
        self._parsed_model_name = None

        if self.model_name is None:
            return

        if "/" in self.model_name:
            self._parsed_model_provider, self._parsed_model_name = (
                self.model_name.split("/", maxsplit=1)
            )
            return

        self._parsed_model_name = self.model_name

    def to_agent_info(self) -> AgentInfo:
        # Record model_info whenever we have a name — provider is optional
        # (``-m gpt-5.4`` without a ``<provider>/`` prefix still yields a
        # usable model identity). The DB-side ``model.provider`` column has
        # a ``DEFAULT 'unknown'`` that takes over for the None case.
        return AgentInfo(
            name=self.name(),
            version=self.version() or "unknown",
            model_info=(
                ModelInfo(
                    name=self._parsed_model_name,
                    provider=self._parsed_model_provider,
                )
                if self._parsed_model_name
                else None
            ),
        )

    def install_spec(self) -> AgentInstallSpec | None:
        """Return build-time install commands for this resolved agent, if any."""
        return None

    def network_allowlist(self) -> NetworkAllowlist:
        """Return network domains this agent may need at runtime."""
        return NetworkAllowlist()

    @staticmethod
    @abstractmethod
    def name() -> str:
        """The name of the agent."""

    @abstractmethod
    def version(self) -> str | None:
        """The version of the agent."""

    @classmethod
    def import_path(cls) -> str:
        """
        The import path of the agent. Formatted as 'some.import.path:AgentClass'.
        """
        return f"{cls.__module__}:{cls.__name__}"

    @abstractmethod
    async def setup(self, environment: BaseEnvironment) -> None:
        """
        Run commands to setup the agent & its tools.

        This is a good place to register the MCP servers in ``self.mcp_servers`` with
        the agent (e.g. by creating a .mcp.json file) and copy skills from
        ``self.skills_dir`` to the agent's expected location.

        The user the agent should run as is available on
        ``environment.default_user``.

        Args:
            environment: The environment in which to setup the agent.
        """

    @abstractmethod
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        """
        Runs the agent in the environment. Be sure to populate the context with the
        results of the agent execution. Ideally, populate the context as the agent
        executes in case of a timeout or other error.

        If necessary, register the MCP servers in ``self.mcp_servers`` with
        the agent (e.g. by creating a .mcp.json file) and copy skills from
        ``self.skills_dir`` to the agent's expected location.

        The user the agent should run as is available on
        ``environment.default_user``. Any call to ``environment.exec`` that does
        not pass an explicit ``user`` argument will automatically run as that
        user.

        Args:
            instruction: The task instruction.
            environment: The environment in which to complete the task.
            context: The context to populate with the results of the agent execution.
        """
