import base64
import json
import shlex
from pathlib import Path
from typing import Any, Literal

from pier.agents.installed.base import (
    BaseInstalledAgent,
    CliFlag,
    with_prompt_template,
)
from pier.agents.network import allowlist_from_urls
from pier.environments.base import BaseEnvironment
from pier.models.agent.context import AgentContext
from pier.models.agent.install import AgentInstallSpec, InstallStep
from pier.models.agent.name import AgentName
from pier.models.agent.network import NetworkAllowlist
from pier.models.trajectories import (
    Agent,
    ContentPart,
    FinalMetrics,
    ImageSource,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    ToolCall,
    Trajectory,
)
from pier.utils.trajectory_metrics import (
    extra_with_context_metrics,
    peak_context_tokens_from_steps,
    populate_context_from_final_metrics,
)

_ImageMediaType = Literal["image/jpeg", "image/png", "image/gif", "image/webp"]
_ReasoningEffort = Literal["minimal", "low", "medium", "high"]
_REASONING_EFFORT_CHOICES = frozenset(("minimal", "low", "medium", "high"))
_FLASH_ONLY_REASONING_EFFORTS = frozenset(("minimal", "medium"))


class GeminiCli(BaseInstalledAgent):
    """
    The Gemini CLI agent uses Google's Gemini CLI tool to solve tasks.
    """

    def get_version_command(self) -> str | None:
        return ". ~/.nvm/nvm.sh; gemini --version"

    SUPPORTS_ATIF: bool = True

    CLI_FLAGS = [
        CliFlag(
            "sandbox",
            cli="--sandbox",
            type="bool",
        ),
    ]

    # Counter for generating unique image filenames within a session
    _image_counter: int = 0

    @staticmethod
    def name() -> str:
        return AgentName.GEMINI_CLI.value

    def __init__(
        self,
        *args,
        reasoning_effort: _ReasoningEffort | None = None,
        **kwargs,
    ):
        self._reasoning_effort = reasoning_effort
        super().__init__(*args, **kwargs)
        self._validate_reasoning_effort(self._reasoning_effort, self.model_name)

    @staticmethod
    def _validate_reasoning_effort(
        reasoning_effort: _ReasoningEffort | None,
        model_name: str | None,
    ) -> None:
        if (
            reasoning_effort is not None
            and reasoning_effort not in _REASONING_EFFORT_CHOICES
        ):
            raise ValueError(
                f"Invalid value for 'reasoning_effort': '{reasoning_effort}'. "
                f"Valid values: {', '.join(sorted(_REASONING_EFFORT_CHOICES))}"
            )
        if reasoning_effort is None or model_name is None:
            return
        if "2.5" in model_name:
            raise ValueError(
                "Gemini 2.5 models do not support reasoning_effort. "
                "Use a Gemini 3 model, or add explicit thinking_budget support."
            )
        if (
            reasoning_effort in _FLASH_ONLY_REASONING_EFFORTS
            and "flash" not in model_name
        ):
            raise ValueError(
                f"Gemini model '{model_name}' does not support "
                f"reasoning_effort='{reasoning_effort}'. "
                "Use 'low' or 'high', or choose a Gemini 3 Flash model."
            )

    def install_spec(self) -> AgentInstallSpec:
        version_spec = f"@{self._version}" if self._version else "@latest"
        root_run = "apt-get update && apt-get install -y curl"
        agent_run = (
            "set -euo pipefail; "
            "curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash && "
            'export NVM_DIR="$HOME/.nvm" && '
            '\\. "$NVM_DIR/nvm.sh" || true && '
            "command -v nvm &>/dev/null || { echo 'Error: NVM failed to load' >&2; exit 1; } && "
            "nvm install 22 && npm -v && "
            f"npm install -g @google/gemini-cli{version_spec}"
        )
        gemini_settings_run = (
            "mkdir -p ~/.gemini && "
            "cat > ~/.gemini/settings.json << 'SETTINGS'\n"
            '{\n  "experimental": {\n    "skills": true\n  }\n}\n'
            "SETTINGS"
        )

        return AgentInstallSpec(
            agent_name=self.name(),
            version=self._version,
            steps=[
                InstallStep(
                    user="root",
                    env={"DEBIAN_FRONTEND": "noninteractive"},
                    run=root_run,
                ),
                InstallStep(
                    user="agent",
                    run=agent_run,
                ),
                InstallStep(
                    user="agent",
                    run=gemini_settings_run,
                ),
                InstallStep(user="agent", run=". ~/.nvm/nvm.sh && gemini --version"),
            ],
            verification_command=self.get_version_command(),
        )

    def network_allowlist(self) -> NetworkAllowlist:
        urls = [
            self._get_env("GOOGLE_GEMINI_BASE_URL"),
            self._get_env("GEMINI_API_BASE"),
        ]
        return allowlist_from_urls(urls, default_domains=[".googleapis.com"])

    def _save_image(
        self,
        image_data: str,
        mime_type: str,
        step_id: int,
        obs_index: int,
        image_index: int = 0,
    ) -> tuple[str, _ImageMediaType] | tuple[None, None]:
        """Save a base64 image to the images directory.

        Args:
            image_data: Base64-encoded image data
            mime_type: MIME type of the image (e.g., 'image/png')
            step_id: The step ID this image belongs to
            obs_index: Index of the observation result within the step
            image_index: Index of the image within the observation (for multiple images)

        Returns:
            Tuple of (relative_path, media_type) for the saved image, or (None, None) on failure
        """
        # Create images directory if it doesn't exist
        images_dir = self.logs_dir / "images"
        images_dir.mkdir(exist_ok=True)

        # Determine file extension from mime type
        # Only accept MIME types that ImageSource validates
        extension_map: dict[_ImageMediaType, str] = {
            "image/png": "png",
            "image/jpeg": "jpg",
            "image/gif": "gif",
            "image/webp": "webp",
        }
        for valid_type, extension in extension_map.items():
            if mime_type == valid_type:
                break
        else:
            # Unsupported MIME type - return None to avoid Pydantic validation error
            self.logger.warning(f"Unsupported image MIME type: {mime_type}")
            return None, None

        # Generate unique filename
        filename = f"step_{step_id}_obs_{obs_index}_img_{image_index}.{extension}"
        image_path = images_dir / filename

        # Decode and save the image
        try:
            image_bytes = base64.b64decode(image_data)
            image_path.write_bytes(image_bytes)
        except Exception as e:
            self.logger.warning(f"Failed to save image: {e}")
            return None, None

        # Return relative path from trajectory.json location
        return f"images/{filename}", valid_type

    @staticmethod
    def _is_summarization_message(message: dict[str, Any]) -> bool:
        """Detect Gemini CLI context compression messages."""
        if message.get("type") not in ("compression", "chat_compressed"):
            return False

        status = message.get("compressionStatus")
        if status is None:
            return True
        if isinstance(status, int):
            return status == 1
        if isinstance(status, str):
            return status.lower() in {"compressed", "compression_status_compressed"}
        return False

    def _convert_gemini_to_atif(
        self, gemini_trajectory: dict[str, Any]
    ) -> Trajectory | None:
        """Convert Gemini CLI trajectory format to ATIF format."""
        session_id = gemini_trajectory.get("sessionId", "unknown")
        messages = gemini_trajectory.get("messages", [])

        if not messages:
            return None

        def _extract_text(content: Any) -> str:
            """Extract text from Gemini content field (list of dicts or string)."""
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                return "\n".join(
                    part.get("text", "") if isinstance(part, dict) else str(part)
                    for part in content
                )
            return str(content) if content else ""

        steps: list[Step] = []
        step_id = 1

        # Track metrics for final_metrics calculation
        total_input_tokens = 0
        total_output_tokens = 0
        total_cached_tokens = 0

        for message in messages:
            msg_type = message.get("type")
            timestamp = message.get("timestamp")

            # User message
            if msg_type == "user":
                content = _extract_text(message.get("content", ""))
                steps.append(
                    Step(
                        step_id=step_id,
                        timestamp=timestamp,
                        source="user",
                        message=content,
                    )
                )
                step_id += 1

            # Gemini (agent) message
            elif msg_type == "gemini":
                content = _extract_text(message.get("content", ""))
                thoughts = message.get("thoughts", [])
                tool_calls_data = message.get("toolCalls", [])
                tokens = message.get("tokens", {})
                model_name = message.get("model")

                # Build reasoning content from thoughts
                reasoning_content: str | None = None
                if thoughts:
                    reasoning_parts = []
                    for thought in thoughts:
                        subject = thought.get("subject", "")
                        description = thought.get("description", "")
                        if subject and description:
                            reasoning_parts.append(f"{subject}: {description}")
                        elif description:
                            reasoning_parts.append(description)
                    if reasoning_parts:
                        reasoning_content = "\n".join(reasoning_parts)

                # Handle tool calls
                tool_calls: list[ToolCall] | None = None
                observation: Observation | None = None

                if tool_calls_data:
                    tool_calls = []
                    observation_results: list[ObservationResult] = []

                    for tc in tool_calls_data:
                        tool_call_id = tc.get("id", "")
                        tool_name = tc.get("name", "")
                        args = tc.get("args", {})
                        result = tc.get("result", [])

                        tool_calls.append(
                            ToolCall(
                                tool_call_id=tool_call_id,
                                function_name=tool_name,
                                arguments=args,
                            )
                        )

                        # Extract observation content from result
                        # This may include text output and/or image data
                        obs_content: str | list[ContentPart] | None = None
                        obs_index = len(observation_results)

                        if result:
                            text_output: str | None = None
                            image_parts: list[ContentPart] = []

                            for res_item in result:
                                if isinstance(res_item, dict):
                                    func_resp = res_item.get("functionResponse", {})
                                    response = func_resp.get("response", {})
                                    output = response.get("output")
                                    if output:
                                        text_output = output

                                    # Check for image data in parts
                                    parts = func_resp.get("parts", [])
                                    image_index = 0
                                    for part in parts:
                                        if isinstance(part, dict):
                                            inline_data = part.get("inlineData", {})
                                            if inline_data:
                                                mime_type = inline_data.get(
                                                    "mimeType", "image/png"
                                                )
                                                data = inline_data.get("data", "")
                                                if data:
                                                    # Save the image and get the path
                                                    image_path, media_type = (
                                                        self._save_image(
                                                            data,
                                                            mime_type,
                                                            step_id,
                                                            obs_index,
                                                            image_index,
                                                        )
                                                    )
                                                    if image_path and media_type:
                                                        image_parts.append(
                                                            ContentPart(
                                                                type="image",
                                                                source=ImageSource(
                                                                    media_type=media_type,
                                                                    path=image_path,
                                                                ),
                                                            )
                                                        )
                                                    image_index += 1

                            # Build observation content
                            if image_parts:
                                # Multimodal content - combine text and images
                                content_parts: list[ContentPart] = []
                                if text_output:
                                    content_parts.append(
                                        ContentPart(type="text", text=text_output)
                                    )
                                content_parts.extend(image_parts)
                                obs_content = content_parts
                            else:
                                # Text-only content
                                obs_content = text_output

                        observation_results.append(
                            ObservationResult(
                                source_call_id=tool_call_id or None,
                                content=obs_content,
                            )
                        )

                    if observation_results:
                        observation = Observation(results=observation_results)

                # Build metrics
                metrics: Metrics | None = None
                if tokens:
                    input_tokens = tokens.get("input", 0)
                    output_tokens = tokens.get("output", 0)
                    cached_tokens = tokens.get("cached", 0)
                    thoughts_tokens = tokens.get("thoughts", 0)
                    tool_tokens = tokens.get("tool", 0)

                    # Calculate completion tokens (output + thoughts + tool)
                    completion_tokens = output_tokens + thoughts_tokens + tool_tokens

                    # Update totals
                    total_input_tokens += input_tokens
                    total_output_tokens += completion_tokens
                    total_cached_tokens += cached_tokens

                    metrics = Metrics(
                        prompt_tokens=input_tokens,
                        completion_tokens=completion_tokens,
                        cached_tokens=cached_tokens,
                        extra={
                            "thoughts_tokens": thoughts_tokens,
                            "tool_tokens": tool_tokens,
                        },
                    )

                steps.append(
                    Step(
                        step_id=step_id,
                        timestamp=timestamp,
                        source="agent",
                        model_name=model_name,
                        message=content,
                        reasoning_content=reasoning_content,
                        tool_calls=tool_calls,
                        observation=observation,
                        metrics=metrics,
                        llm_call_count=1,
                    )
                )
                step_id += 1

        if not steps:
            return None

        summarization_count = sum(
            1 for message in messages if self._is_summarization_message(message)
        )
        final_extra = {"compacted": True} if summarization_count else None
        final_extra = extra_with_context_metrics(
            final_extra,
            peak_context_tokens=peak_context_tokens_from_steps(steps),
            summarization_count=summarization_count,
        )

        # Build final metrics
        final_metrics = FinalMetrics(
            total_prompt_tokens=total_input_tokens,
            total_completion_tokens=total_output_tokens,
            total_cached_tokens=total_cached_tokens,
            total_cost_usd=self._compute_cost_from_pricing(
                total_input_tokens, total_output_tokens, total_cached_tokens
            ),
            total_steps=len(steps),
            extra=final_extra,
        )

        # Determine model name from first agent step
        default_model_name: str | None = None
        for step in steps:
            if step.source == "agent" and step.model_name:
                default_model_name = step.model_name
                break

        # Build trajectory
        trajectory = Trajectory(
            schema_version="ATIF-v1.7",
            session_id=session_id,
            agent=Agent(
                name="gemini-cli",
                version=self.version() or "unknown",
                model_name=default_model_name,
            ),
            steps=steps,
            final_metrics=final_metrics,
        )

        return trajectory

    def _load_gemini_session(self, path: Path) -> dict[str, Any] | None:
        text = path.read_text()
        if not text.strip():
            return None

        try:
            data = json.loads(text)
            if isinstance(data, dict) and "messages" in data:
                return data
        except json.JSONDecodeError:
            pass

        metadata: dict[str, Any] = {}
        message_ids: list[str] = []
        messages_by_id: dict[str, dict[str, Any]] = {}

        for line in text.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            try:
                record = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue

            if "$rewindTo" in record:
                rewind_id = record["$rewindTo"]
                if rewind_id in message_ids:
                    idx = message_ids.index(rewind_id)
                    for removed in message_ids[idx:]:
                        messages_by_id.pop(removed, None)
                    del message_ids[idx:]
                else:
                    message_ids.clear()
                    messages_by_id.clear()
            elif "$set" in record and isinstance(record["$set"], dict):
                metadata.update(record["$set"])
            elif "id" in record and "type" in record:
                mid = record["id"]
                if mid not in messages_by_id:
                    message_ids.append(mid)
                messages_by_id[mid] = record
            elif "sessionId" in record:
                for key, value in record.items():
                    if key != "messages":
                        metadata[key] = value

        if not message_ids and not metadata:
            return None

        result: dict[str, Any] = {
            "sessionId": metadata.get("sessionId", "unknown"),
            "messages": [messages_by_id[mid] for mid in message_ids],
        }
        for key, value in metadata.items():
            if key not in ("sessionId", "messages"):
                result[key] = value
        return result

    def _compute_cost_from_pricing(
        self,
        prompt_tokens: int | None,
        completion_tokens: int | None,
        cached_tokens: int | None,
    ) -> float | None:
        if not self.model_name:
            return None

        try:
            import litellm
        except ImportError:
            self.logger.warning("litellm not available; cost_usd left as None")
            return None

        pricing: dict[str, Any] | None = None
        for key in (self.model_name, self.model_name.split("/", 1)[-1]):
            entry = litellm.model_cost.get(key)
            if entry:
                pricing = entry
                break

        if pricing is None:
            self.logger.warning(
                "No LiteLLM pricing for '%s'; cost_usd left as None",
                self.model_name,
            )
            return None

        input_rate = pricing.get("input_cost_per_token") or 0.0
        output_rate = pricing.get("output_cost_per_token") or 0.0
        cache_read_rate = pricing.get("cache_read_input_token_cost") or input_rate

        uncached = max(0, (prompt_tokens or 0) - (cached_tokens or 0))
        cached = cached_tokens or 0
        output = completion_tokens or 0

        return uncached * input_rate + cached * cache_read_rate + output * output_rate

    def populate_context_post_run(self, context: AgentContext) -> None:
        gemini_path: Path | None = None
        for candidate in ("gemini-cli.trajectory.jsonl", "gemini-cli.trajectory.json"):
            path = self.logs_dir / candidate
            if path.exists():
                gemini_path = path
                break

        if gemini_path is None:
            return

        gemini_trajectory = self._load_gemini_session(gemini_path)
        if gemini_trajectory is None:
            self.logger.debug(f"Could not parse Gemini session at {gemini_path}")
            return

        n_input_tokens = 0
        n_output_tokens = 0
        n_cache_tokens = 0
        for message in gemini_trajectory.get("messages", []):
            if message.get("type") == "gemini":
                tokens = message.get("tokens") or {}
                n_input_tokens += tokens.get("input", 0)
                n_output_tokens += (
                    tokens.get("output", 0)
                    + tokens.get("tool", 0)
                    + tokens.get("thoughts", 0)
                )
                n_cache_tokens += tokens.get("cached", 0)

        context.n_input_tokens = n_input_tokens
        context.n_output_tokens = n_output_tokens
        context.n_cache_tokens = n_cache_tokens
        context.cost_usd = self._compute_cost_from_pricing(
            n_input_tokens, n_output_tokens, n_cache_tokens
        )

        try:
            atif_trajectory = self._convert_gemini_to_atif(gemini_trajectory)

            if atif_trajectory:
                atif_path = self.logs_dir / "trajectory.json"
                with open(atif_path, "w") as f:
                    json.dump(atif_trajectory.to_json_dict(), f, indent=2)
                if atif_trajectory.final_metrics:
                    populate_context_from_final_metrics(
                        context, atif_trajectory.final_metrics
                    )
        except Exception as e:
            self.logger.debug(f"Error converting Gemini trajectory to ATIF: {e}")

    def _build_register_skills_command(self) -> str | None:
        """Return a shell command that copies skills to Gemini CLI's skills directory."""
        if not self.skills_dir:
            return None
        return (
            f"mkdir -p ~/.gemini/skills && "
            f"cp -r {shlex.quote(self.skills_dir)}/* "
            f"~/.gemini/skills/ 2>/dev/null || true"
        )

    def _build_settings_config(
        self, model: str | None = None
    ) -> tuple[dict[str, Any] | None, str | None]:
        """Build Gemini CLI settings and optional model alias for this run."""
        config: dict[str, Any] = {}
        model_alias: str | None = None

        if self.mcp_servers:
            servers = {}
            for server in self.mcp_servers:
                if server.transport == "stdio":
                    servers[server.name] = {
                        "command": server.command,
                        "args": server.args,
                    }
                elif server.transport == "streamable-http":
                    servers[server.name] = {"httpUrl": server.url}
                else:  # sse
                    servers[server.name] = {"url": server.url}
            config["mcpServers"] = servers

        if model and self._reasoning_effort:
            model_alias = f"pier-{model}-{self._reasoning_effort}"
            config["modelConfigs"] = {
                "customAliases": {
                    model_alias: {
                        "modelConfig": {
                            "model": model,
                            "generateContentConfig": {
                                "thinkingConfig": {
                                    "includeThoughts": True,
                                    "thinkingLevel": self._reasoning_effort.upper(),
                                },
                            },
                        }
                    }
                }
            }

        if not config:
            return None, None

        config["experimental"] = {"skills": True}
        return config, model_alias

    def _build_settings_command(
        self, model: str | None = None
    ) -> tuple[str | None, str | None]:
        """Return the settings write command and optional run model alias."""
        config, model_alias = self._build_settings_config(model)
        if config is None:
            return None, model_alias
        escaped = shlex.quote(json.dumps(config, indent=2))
        command = f"mkdir -p ~/.gemini && printf %s {escaped} > ~/.gemini/settings.json"
        return command, model_alias

    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        escaped_instruction = shlex.quote(instruction)

        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        model = self.model_name.split("/")[-1]

        # Gemini CLI refuses to honor `--yolo` in an untrusted workspace and
        # overrides approval mode back to "default"
        env = self.build_process_env({"GEMINI_CLI_TRUST_WORKSPACE": "true"})

        auth_vars = [
            "GEMINI_API_KEY",
            "GOOGLE_GEMINI_BASE_URL",
            "GOOGLE_APPLICATION_CREDENTIALS",
            "GOOGLE_CLOUD_PROJECT",
            "GOOGLE_CLOUD_LOCATION",
            "GOOGLE_GENAI_USE_VERTEXAI",
            "GOOGLE_API_KEY",
        ]
        for var in auth_vars:
            if value := self._get_env(var):
                env[var] = value

        skills_command = self._build_register_skills_command()
        if skills_command:
            await self.exec_as_agent(environment, command=skills_command, env=env)

        settings_command, model_alias = self._build_settings_command(model)
        if settings_command:
            await self.exec_as_agent(environment, command=settings_command, env=env)

        cli_flags = self.build_cli_flags()
        extra_flags = (cli_flags + " ") if cli_flags else ""
        run_model = shlex.quote(model_alias or model)

        try:
            await self.exec_as_agent(
                environment,
                command=(
                    ". ~/.nvm/nvm.sh; "
                    f"gemini --yolo {extra_flags}--model={run_model} --prompt={escaped_instruction} "
                    f"2>&1 </dev/null | stdbuf -oL tee /logs/agent/gemini-cli.txt"
                ),
                env=env,
            )
        finally:
            try:
                await self.exec_as_agent(
                    environment,
                    command=(
                        "src=$(find ~/.gemini/tmp -type f "
                        "\\( -name 'session-*.jsonl' -o -name 'session-*.json' \\) "
                        "-printf '%T@ %p\\n' 2>/dev/null | sort -nr | head -n1 "
                        "| awk '{print $2}'); "
                        'if [ -n "$src" ]; then '
                        'cp "$src" "/logs/agent/gemini-cli.trajectory.${src##*.}"; '
                        "fi"
                    ),
                )
            except Exception:
                pass
