import copy
import json
import shlex
from datetime import datetime, timezone
from typing import Any

from pier.agents.installed.base import (
    BaseInstalledAgent,
    CliFlag,
    NonZeroAgentExitCodeError,
    with_prompt_template,
)
from pier.agents.network import allowlist_from_urls, collect_url_values
from pier.environments.base import BaseEnvironment
from pier.models.agent.context import AgentContext
from pier.models.agent.install import AgentInstallSpec, InstallStep
from pier.models.agent.name import AgentName
from pier.models.agent.network import NetworkAllowlist
from pier.models.trajectories import (
    Agent,
    FinalMetrics,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    ToolCall,
    Trajectory,
)
from pier.utils.trajectory_metrics import (
    extra_with_context_metrics,
    peak_context_tokens_from_steps,
    populate_context_from_final_metrics,
)
from pier.utils.trajectory_utils import format_trajectory_json


class OpenCode(BaseInstalledAgent):
    """
    The OpenCode agent uses the opencode-ai tool to solve tasks.

    Parses the JSON lines emitted by ``opencode run --format=json`` (captured
    to ``opencode.txt``) into an ATIF trajectory.

    Stdout JSON line types:
        text          - agent text output (part.type == "text")
        reasoning     - optional explicit reasoning text (part.type == "reasoning")
        tool_use      - tool call with input/output (part.type == "tool")
        step_start    - marks the beginning of an agent turn
        step_finish   - marks the end of a turn, carries cost & token data
        error         - error event
    """

    SUPPORTS_ATIF: bool = True

    _OUTPUT_FILENAME = "opencode.txt"
    CLI_FLAGS = [
        CliFlag("variant", cli="--variant", type="str"),
    ]

    # Base config written to opencode.json before each run.
    # Extend per-job via ``opencode_config`` in agents[].kwargs, e.g.:
    #
    #   opencode_config:
    #     experimental:
    #       continue_loop_on_deny: true
    _DEFAULT_CONFIG: dict[str, Any] = {}
    _DEFAULT_PROVIDER_DOMAINS: dict[str, list[str]] = {
        "anthropic": ["api.anthropic.com"],
        "deepseek": ["api.deepseek.com"],
        "google": [".googleapis.com"],
        "groq": ["api.groq.com"],
        "mistral": ["api.mistral.ai"],
        "openai": ["api.openai.com"],
        "openrouter": ["openrouter.ai"],
        "xai": ["api.x.ai"],
    }

    def __init__(self, *args, opencode_config: dict[str, Any] | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._opencode_config: dict[str, Any] = opencode_config or {}

    @staticmethod
    def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """Merge *override* into *base* in place, recursing into nested dicts."""
        for key, value in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                OpenCode._deep_merge(base[key], value)
            else:
                base[key] = value
        return base

    @staticmethod
    def name() -> str:
        return AgentName.OPENCODE.value

    def get_version_command(self) -> str | None:
        return ". ~/.nvm/nvm.sh; opencode --version"

    def install_spec(self) -> AgentInstallSpec:
        version_spec = f"@{self._version}" if self._version else "@latest"
        return AgentInstallSpec(
            agent_name=self.name(),
            version=self._version,
            steps=[
                InstallStep(
                    user="root",
                    env={"DEBIAN_FRONTEND": "noninteractive"},
                    run="apt-get update && apt-get install -y curl",
                ),
                InstallStep(
                    user="agent",
                    run=(
                        "set -euo pipefail; "
                        "curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash && "
                        'export NVM_DIR="$HOME/.nvm" && '
                        '\\. "$NVM_DIR/nvm.sh" || true && '
                        "command -v nvm &>/dev/null || { echo 'Error: NVM failed to load' >&2; exit 1; } && "
                        "nvm install 22 && npm -v && "
                        f"npm i -g opencode-ai{version_spec} && "
                        "opencode --version"
                    ),
                ),
            ],
            verification_command=self.get_version_command(),
        )

    @staticmethod
    def _millis_to_iso(timestamp_ms: int | float | None) -> str | None:
        """Convert a millisecond Unix timestamp to ISO 8601 string."""
        if timestamp_ms is None:
            return None
        try:
            return datetime.fromtimestamp(
                timestamp_ms / 1000, tz=timezone.utc
            ).isoformat()
        except (OSError, ValueError, OverflowError):
            return None

    def _parse_stdout(self) -> list[dict[str, Any]]:
        """Read and parse JSON lines from the opencode stdout file."""
        output_path = self.logs_dir / self._OUTPUT_FILENAME
        if not output_path.exists():
            return []

        events: list[dict[str, Any]] = []
        for line in output_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return events

    def _error_messages(self) -> list[str]:
        """Return messages from OpenCode error events in stdout."""
        messages: list[str] = []
        for event in self._parse_stdout():
            if event.get("type") != "error":
                continue
            error = event.get("error")
            if isinstance(error, dict):
                data = error.get("data")
                message = data.get("message") if isinstance(data, dict) else None
                messages.append(str(message or error.get("name") or error))
            else:
                messages.append(str(error))
        return messages

    def _convert_events_to_trajectory(
        self, events: list[dict[str, Any]]
    ) -> Trajectory | None:
        """Convert opencode stdout JSON events into an ATIF trajectory.

        Events are grouped into agent steps by ``step_start`` / ``step_finish``
        boundaries.  Each group of events between a ``step_start`` and
        ``step_finish`` becomes one ATIF Step with source="agent".  A user Step
        is synthesised at the beginning (the instruction is in opencode.txt only
        as a CLI arg, not as an event, so we use a placeholder).
        """
        if not events:
            return None

        session_id: str | None = None
        for event in events:
            sid = event.get("sessionID")
            if sid:
                session_id = sid
                break

        # Group events into turns delimited by step_start / step_finish
        turns: list[dict[str, Any]] = []
        current_turn: dict[str, Any] | None = None

        for event in events:
            etype = event.get("type")

            if etype == "step_start":
                current_turn = {
                    "parts": [],
                    "finish": None,
                    "timestamp": event.get("timestamp"),
                }
                continue

            if etype == "step_finish":
                if current_turn is not None:
                    current_turn["finish"] = event.get("part", {})
                    turns.append(current_turn)
                    current_turn = None
                continue

            if current_turn is not None and etype in ("text", "reasoning", "tool_use"):
                current_turn["parts"].append(event.get("part", {}))

        steps: list[Step] = []
        step_id = 1
        total_cost = 0.0
        total_input_tokens = 0
        total_output_tokens = 0
        total_cache_read = 0

        for turn in turns:
            text_parts: list[str] = []
            reasoning_parts: list[str] = []
            tool_calls_list: list[ToolCall] = []
            observation_results: list[ObservationResult] = []
            timestamp = self._millis_to_iso(turn.get("timestamp"))

            for part in turn["parts"]:
                ptype = part.get("type")

                if ptype == "text":
                    text = part.get("text", "")
                    if text:
                        text_parts.append(text)

                elif ptype == "reasoning":
                    reasoning = part.get("text", "")
                    if reasoning:
                        reasoning_parts.append(reasoning)

                elif ptype == "tool":
                    state = part.get("state", {})
                    tool_name = part.get("tool", "")
                    tool_input = state.get("input", {})
                    tool_output = state.get("output")
                    call_id = part.get("callID", part.get("id", ""))

                    if not isinstance(tool_input, dict):
                        tool_input = {"value": tool_input} if tool_input else {}

                    tool_calls_list.append(
                        ToolCall(
                            tool_call_id=call_id,
                            function_name=tool_name,
                            arguments=tool_input,
                        )
                    )

                    if tool_output is not None:
                        observation_results.append(
                            ObservationResult(
                                source_call_id=call_id or None,
                                content=str(tool_output),
                            )
                        )

            # Extract metrics from step_finish
            finish = turn.get("finish", {})
            tokens = finish.get("tokens", {})
            cost = finish.get("cost", 0) or 0
            input_tok = tokens.get("input", 0) or 0
            output_tok = tokens.get("output", 0) or 0
            reasoning_tok = tokens.get("reasoning", 0) or 0
            cache = tokens.get("cache", {})
            cache_read = cache.get("read", 0) or 0
            cache_write = cache.get("write", 0) or 0

            total_cost += cost
            total_input_tokens += input_tok + cache_read
            total_output_tokens += output_tok
            total_cache_read += cache_read

            metrics: Metrics | None = None
            if input_tok or output_tok or cache_read:
                metrics = Metrics(
                    prompt_tokens=input_tok + cache_read,
                    completion_tokens=output_tok,
                    cached_tokens=cache_read if cache_read else None,
                    cost_usd=cost if cost else None,
                    extra={
                        k: v
                        for k, v in {
                            "reasoning_tokens": reasoning_tok,
                            "cache_write_tokens": cache_write,
                        }.items()
                        if v
                    }
                    or None,
                )

            message_text = "\n".join(text_parts) if text_parts else ""
            observation = (
                Observation(results=observation_results)
                if observation_results
                else None
            )

            step_kwargs: dict[str, Any] = {
                "step_id": step_id,
                "timestamp": timestamp,
                "source": "agent",
                "message": message_text,
                "model_name": self.model_name,
                "llm_call_count": 1,
            }
            if reasoning_parts:
                step_kwargs["reasoning_content"] = "\n\n".join(reasoning_parts)
            if tool_calls_list:
                step_kwargs["tool_calls"] = tool_calls_list
            if observation:
                step_kwargs["observation"] = observation
            if metrics:
                step_kwargs["metrics"] = metrics

            steps.append(Step(**step_kwargs))
            step_id += 1

        if not steps:
            return None

        final_metrics = FinalMetrics(
            total_prompt_tokens=total_input_tokens or None,
            total_completion_tokens=total_output_tokens or None,
            total_cached_tokens=total_cache_read or None,
            total_cost_usd=total_cost if total_cost else None,
            total_steps=len(steps),
            extra=extra_with_context_metrics(
                None,
                peak_context_tokens=peak_context_tokens_from_steps(steps),
                summarization_count=None,
            ),
        )

        return Trajectory(
            schema_version="ATIF-v1.7",
            session_id=session_id or "unknown",
            agent=Agent(
                name="opencode",
                version=self.version() or "unknown",
                model_name=self.model_name,
            ),
            steps=steps,
            final_metrics=final_metrics,
        )

    def populate_context_post_run(self, context: AgentContext) -> None:
        """Parse opencode stdout and convert to ATIF trajectory."""
        events = self._parse_stdout()
        if not events:
            return

        try:
            trajectory = self._convert_events_to_trajectory(events)
        except Exception:
            self.logger.exception("Failed to convert opencode events to trajectory")
            return

        if not trajectory:
            return

        trajectory_path = self.logs_dir / "trajectory.json"
        try:
            trajectory_path.write_text(
                format_trajectory_json(trajectory.to_json_dict())
            )
            self.logger.debug(f"Wrote opencode trajectory to {trajectory_path}")
        except OSError as exc:
            self.logger.debug(
                f"Failed to write trajectory file {trajectory_path}: {exc}"
            )

        if trajectory.final_metrics:
            populate_context_from_final_metrics(context, trajectory.final_metrics)

    def _build_register_skills_command(self) -> str | None:
        """Return a shell command that copies skills to OpenCode's skills directory."""
        if not self.skills_dir:
            return None
        return (
            f"mkdir -p ~/.config/opencode/skills && "
            f"cp -r {shlex.quote(self.skills_dir)}/* "
            f"~/.config/opencode/skills/ 2>/dev/null || true"
        )

    def _build_register_config_command(self) -> str | None:
        """Return a shell command that writes the opencode config to ~/.config/opencode/opencode.json.

        The config may include MCP server definitions and/or a provider model
        registration so opencode recognises models not in its built-in registry.
        """
        config = self._build_runtime_config(include_mcp=True)

        if not config:
            return None

        config_json = json.dumps(config, indent=2)
        escaped = shlex.quote(config_json)
        return f"mkdir -p ~/.config/opencode && echo {escaped} > ~/.config/opencode/opencode.json"

    def _build_runtime_config(self, *, include_mcp: bool) -> dict[str, Any]:
        config: dict[str, Any] = {}

        if include_mcp and self.mcp_servers:
            mcp: dict[str, dict[str, Any]] = {}
            for server in self.mcp_servers:
                if server.transport == "stdio":
                    cmd_list = [server.command] + server.args if server.command else []
                    mcp[server.name] = {"type": "local", "command": cmd_list}
                else:  # sse or streamable-http
                    mcp[server.name] = {"type": "remote", "url": server.url}
            config["mcp"] = mcp

        if self.model_name and "/" in self.model_name:
            provider, model_id = self.model_name.split("/", 1)
            provider_config: dict[str, Any] = {"models": {model_id: {}}}
            base_url = self._get_env("OPENAI_BASE_URL")
            if base_url and provider == "openai":
                # opencode reads baseURL from provider.options, not the provider root.
                # See: https://github.com/anomalyco/opencode config.ts ProviderConfig schema.
                provider_config.setdefault("options", {})["baseURL"] = base_url
            config["provider"] = {provider: provider_config}

        # Layer: defaults → auto-generated → job-level overrides.
        # Deep-merge preserves sibling keys within nested dicts (e.g. provider, experimental).
        config = self._deep_merge(copy.deepcopy(self._DEFAULT_CONFIG), config)
        config = self._deep_merge(config, self._opencode_config)
        return config

    def network_allowlist(self) -> NetworkAllowlist:
        if not self.model_name or "/" not in self.model_name:
            return NetworkAllowlist()

        provider, _ = self.model_name.split("/", 1)
        config = self._build_runtime_config(include_mcp=False)
        provider_config = (config.get("provider") or {}).get(provider) or {}
        urls = collect_url_values(provider_config)
        return allowlist_from_urls(
            urls,
            default_domains=self._DEFAULT_PROVIDER_DOMAINS.get(provider, []),
        )

    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        escaped_instruction = shlex.quote(instruction)

        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        provider, _ = self.model_name.split("/", 1)

        env = self.build_process_env()
        keys = []

        # Get provider environment variables
        if provider == "amazon-bedrock":
            keys.extend(["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION"])
        elif provider == "anthropic":
            keys.append("ANTHROPIC_API_KEY")
        elif provider == "azure":
            keys.extend(["AZURE_RESOURCE_NAME", "AZURE_API_KEY"])
        elif provider == "deepseek":
            keys.append("DEEPSEEK_API_KEY")
        elif provider == "github-copilot":
            keys.append("GITHUB_TOKEN")
        elif provider == "google":
            keys.extend(
                [
                    "GEMINI_API_KEY",
                    "GOOGLE_GENERATIVE_AI_API_KEY",
                    "GOOGLE_APPLICATION_CREDENTIALS",
                    "GOOGLE_CLOUD_PROJECT",
                    "GOOGLE_CLOUD_LOCATION",
                    "GOOGLE_GENAI_USE_VERTEXAI",
                    "GOOGLE_API_KEY",
                ]
            )
        elif provider == "groq":
            keys.append("GROQ_API_KEY")
        elif provider == "huggingface":
            keys.append("HF_TOKEN")
        elif provider == "llama":
            keys.append("LLAMA_API_KEY")
        elif provider == "mistral":
            keys.append("MISTRAL_API_KEY")
        elif provider == "openai":
            keys.append("OPENAI_API_KEY")
            keys.append("OPENAI_BASE_URL")
        elif provider == "opencode":
            keys.append("OPENCODE_API_KEY")
        elif provider == "xai":
            keys.append("XAI_API_KEY")
        elif provider == "openrouter":
            keys.append("OPENROUTER_API_KEY")

        for key in keys:
            if value := self._get_env(key):
                env[key] = value

        # Enable fake VCS for OpenCode
        env["OPENCODE_FAKE_VCS"] = "git"

        skills_command = self._build_register_skills_command()
        if skills_command:
            await self.exec_as_agent(environment, command=skills_command, env=env)

        mcp_command = self._build_register_config_command()
        if mcp_command:
            await self.exec_as_agent(environment, command=mcp_command, env=env)

        cli_flags = self.build_cli_flags()
        cli_flags_arg = (cli_flags + " ") if cli_flags else ""

        await self.exec_as_agent(
            environment,
            # Note that the --thinking flag just means thinking blocks will be included in the json formatted output
            command=(
                ". ~/.nvm/nvm.sh; "
                f"opencode --model={self.model_name} run --format=json {cli_flags_arg}--thinking --dangerously-skip-permissions -- {escaped_instruction} "
                f"2>&1 </dev/null | stdbuf -oL tee /logs/agent/opencode.txt"
            ),
            env=env,
        )

        if messages := self._error_messages():
            raise NonZeroAgentExitCodeError(
                "OpenCode emitted error event(s): " + "; ".join(messages[:3])
            )
