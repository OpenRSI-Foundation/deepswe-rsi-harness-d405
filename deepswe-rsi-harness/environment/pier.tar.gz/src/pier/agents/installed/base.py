import functools
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Literal

if TYPE_CHECKING:
    from pier.models.agent.context import AgentContext

from pier.agents.base import BaseAgent
from pier.environments.base import BaseEnvironment
from pier.models.agent.install import AgentInstallSpec
from pier.utils.env import parse_bool_env_value
from pier.utils.templating import render_prompt_template


class NonZeroAgentExitCodeError(RuntimeError):
    """Raised when the agent process exits with a non-zero exit code."""

    pass


_F = Any  # Use Any to keep the decorator signature-transparent to type checkers


def with_prompt_template(fn: _F) -> _F:
    """Decorator for ``run()`` that applies prompt-template rendering.

    Usage::

        @with_prompt_template
        async def run(self, instruction, environment, context):
            # instruction is already rendered through the prompt template
            ...
    """

    @functools.wraps(fn)
    async def wrapper(
        self: BaseInstalledAgent, instruction: str, *args: Any, **kwargs: Any
    ) -> None:
        instruction = self.render_instruction(instruction)
        return await fn(self, instruction, *args, **kwargs)

    return wrapper


@dataclass
class CliFlag:
    """Declarative CLI flag that maps a kwarg to a command-line flag."""

    kwarg: str
    cli: str
    type: Literal["str", "int", "bool", "enum"] = "str"
    choices: list[str] | None = None
    default: Any = None
    env_fallback: str | None = None
    format: str | None = None


@dataclass
class EnvVar:
    """Declarative env var that maps a kwarg to an environment variable."""

    kwarg: str
    env: str
    type: Literal["str", "int", "bool", "enum"] = "str"
    choices: list[str] | None = None
    default: Any = None
    env_fallback: str | None = None
    bool_true: str = "true"
    bool_false: str = "false"


def _coerce_value(
    value: Any,
    type: Literal["str", "int", "bool", "enum"],
    choices: list[str] | None,
    kwarg_name: str,
) -> Any:
    """Coerce a value to the specified type, raising ValueError on failure."""
    match type:
        case "str":
            if isinstance(value, bool):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected str, got bool"
                )
            if isinstance(value, (int, float)):
                return str(value)
            if not isinstance(value, str):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected str, got {value.__class__.__name__}"
                )
            return value

        case "int":
            if isinstance(value, bool):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected int, got bool"
                )
            if isinstance(value, int):
                return value
            if isinstance(value, float):
                if value != int(value):
                    raise ValueError(
                        f"Invalid value for '{kwarg_name}': float {value} is not an integer"
                    )
                return int(value)
            if isinstance(value, str):
                try:
                    return int(value)
                except ValueError:
                    raise ValueError(
                        f"Invalid value for '{kwarg_name}': cannot parse '{value}' as int"
                    )
            raise ValueError(
                f"Invalid value for '{kwarg_name}': expected int, got {value.__class__.__name__}"
            )

        case "bool":
            return parse_bool_env_value(value, name=kwarg_name)

        case "enum":
            if not isinstance(value, str):
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': expected str for enum, got {value.__class__.__name__}"
                )
            normalized = value.strip().lower()
            if choices and normalized not in choices:
                raise ValueError(
                    f"Invalid value for '{kwarg_name}': '{value}'. "
                    f"Valid values: {', '.join(sorted(choices))}"
                )
            return normalized

        case _:
            raise ValueError(f"Unknown type '{type}' for kwarg '{kwarg_name}'")


class BaseInstalledAgent(BaseAgent, ABC):
    """
    An interface for agents that are installed and run in the environment.
    """

    CLI_FLAGS: ClassVar[list[CliFlag]] = []
    ENV_VARS: ClassVar[list[EnvVar]] = []

    def __init__(
        self,
        logs_dir: Path,
        prompt_template_path: Path | str | None = None,
        version: str | None = None,
        extra_env: dict[str, str] | None = None,
        *args,
        **kwargs,
    ):
        # Auto-extract kwargs matching CLI_FLAGS and ENV_VARS descriptors
        self._flag_kwargs: dict[str, Any] = {}
        for descriptor in [*self.CLI_FLAGS, *self.ENV_VARS]:
            if descriptor.kwarg in kwargs:
                self._flag_kwargs[descriptor.kwarg] = kwargs.pop(descriptor.kwarg)

        self._extra_env: dict[str, str] = dict(extra_env) if extra_env else {}

        super().__init__(logs_dir, *args, **kwargs)

        # Resolve and validate all descriptor values eagerly
        self._resolved_flags = self._resolve_flag_values()
        self._resolved_env_vars = self._resolve_env_values()

        self._prompt_template_path = (
            Path(prompt_template_path) if prompt_template_path else None
        )
        self._version = version

    def _resolve_raw_value(
        self,
        descriptor: CliFlag | EnvVar,
    ) -> Any:
        """Get the raw value for a descriptor from kwargs, then env_fallback, then default."""
        if descriptor.kwarg in self._flag_kwargs:
            return self._flag_kwargs[descriptor.kwarg]
        if descriptor.env_fallback and descriptor.env_fallback in os.environ:
            return os.environ[descriptor.env_fallback]
        return descriptor.default

    def _resolve_flag_values(self) -> dict[str, Any]:
        """Resolve all CLI_FLAGS to their final coerced values (non-None only)."""
        resolved: dict[str, Any] = {}
        for flag in self.CLI_FLAGS:
            raw = self._resolve_raw_value(flag)
            if raw is None:
                continue
            resolved[flag.kwarg] = _coerce_value(
                raw, flag.type, flag.choices, flag.kwarg
            )
        return resolved

    def build_cli_flags(self) -> str:
        """Build the CLI flags string from CLI_FLAGS descriptors.

        Returns a string like '--max-turns 5 --effort high' ready to insert into a command.
        """
        parts: list[str] = []
        for flag in self.CLI_FLAGS:
            value = self._resolved_flags.get(flag.kwarg)
            if value is None:
                continue
            if flag.format is not None:
                parts.append(flag.format.format(value=value))
            elif flag.type == "bool":
                if value:
                    parts.append(flag.cli)
            else:
                parts.append(f"{flag.cli} {value}")
        return " ".join(parts)

    def _resolve_env_values(self) -> dict[str, str]:
        """Resolve all ENV_VARS to their final {env_name: string_value} dict (non-None only)."""
        resolved: dict[str, str] = {}
        for env_var in self.ENV_VARS:
            raw = self._resolve_raw_value(env_var)
            if raw is None:
                continue
            coerced = _coerce_value(raw, env_var.type, env_var.choices, env_var.kwarg)
            if env_var.type == "bool":
                resolved[env_var.env] = (
                    env_var.bool_true if coerced else env_var.bool_false
                )
            else:
                resolved[env_var.env] = str(coerced)
        return resolved

    def resolve_env_vars(self) -> dict[str, str]:
        """Public access to resolved env vars dict."""
        return dict(self._resolved_env_vars)

    def build_process_env(
        self,
        base: dict[str, str | None] | None = None,
        *,
        include_resolved_env: bool = True,
    ) -> dict[str, str]:
        """Build runtime env with explicit agent.env values included.

        ``agent.env`` is the simple escape hatch for provider gateways, custom
        base URLs, and tool-specific environment variables. Agent code can pass
        its normal defaults as ``base``; job-level env then overrides those
        defaults, and declarative EnvVar kwargs override both.
        """
        env = {key: value for key, value in (base or {}).items() if value is not None}
        env.update(self._extra_env)
        if include_resolved_env:
            env.update(self._resolved_env_vars)
        return env

    def _get_env(self, key: str) -> str | None:
        """Get env var from extra_env (priority) or os.environ."""
        if key in self._extra_env:
            return self._extra_env[key]
        return os.environ.get(key)

    def _has_env(self, key: str) -> bool:
        """Check if env var exists in extra_env or os.environ."""
        return key in self._extra_env or key in os.environ

    def _get_env_prefixed(self, prefix: str) -> dict[str, str]:
        """Get all env vars with prefix from extra_env and os.environ (extra_env wins)."""
        result: dict[str, str] = {}
        for key, value in os.environ.items():
            if key.startswith(prefix):
                result[key[len(prefix) :]] = value
        for key, value in self._extra_env.items():
            if key.startswith(prefix):
                result[key[len(prefix) :]] = value
        return result

    @abstractmethod
    def populate_context_post_run(self, context: "AgentContext") -> None:
        """Populate the context with the results of the agent execution.

        Called by the trial after ``run()`` completes (even on failure).
        Typically involves parsing trajectory files and extracting token counts.
        """
        pass

    def version(self) -> str | None:
        return self._version

    def get_version_command(self) -> str | None:
        """Return a shell command that prints the agent version to stdout.
        Override in subclasses to enable auto-detection after setup."""
        return None

    def parse_version(self, stdout: str) -> str:
        """Parse the output of get_version_command into a version string.
        Override in subclasses if the command output needs parsing."""
        return stdout.strip()

    def _truncate_output(self, text: str | None, max_len: int = 1000) -> str:
        if not text:
            return "None"
        if len(text) > max_len:
            return text[:max_len] + " ... [truncated]"
        return text

    async def _exec(
        self,
        environment: BaseEnvironment,
        command: str,
        user: str | int | None = None,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_sec: int | None = None,
    ) -> Any:
        """Execute a command with logging, _extra_env merging, and error handling.

        Returns the ExecResult on success, raises RuntimeError on failure.
        """
        merged_env = env
        if self._extra_env:
            merged_env = dict(env) if env else {}
            merged_env.update(self._extra_env)

        self.logger.debug(
            f"Running command: {command}",
            extra={
                "user": str(user),
                "env": merged_env or {},
            },
        )

        result = await environment.exec(
            command=f"set -o pipefail; {command}",
            user=user,
            env=environment.agent_process_env(merged_env),
            cwd=cwd,
            timeout_sec=timeout_sec,
        )
        if result.return_code != 0:
            self.logger.debug(
                "Command failed",
                extra={
                    "return_code": result.return_code,
                    "stdout": self._truncate_output(result.stdout),
                    "stderr": self._truncate_output(result.stderr),
                },
            )
            raise NonZeroAgentExitCodeError(
                f"Command failed (exit {result.return_code}): {command}\n"
                f"stdout: {self._truncate_output(result.stdout)}\n"
                f"stderr: {self._truncate_output(result.stderr)}"
            )

        self.logger.debug(
            "Command outputs captured",
            extra={
                "stdout": self._truncate_output(result.stdout),
                "stderr": self._truncate_output(result.stderr),
            },
        )
        return result

    async def exec_as_root(
        self,
        environment: BaseEnvironment,
        command: str,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_sec: int | None = None,
    ) -> Any:
        """Execute a command as root (for system packages, symlinks, etc.)."""
        return await self._exec(
            environment, command, user="root", env=env, cwd=cwd, timeout_sec=timeout_sec
        )

    async def exec_as_agent(
        self,
        environment: BaseEnvironment,
        command: str,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_sec: int | None = None,
    ) -> Any:
        """Execute a command as the default agent user."""
        return await self._exec(
            environment, command, env=env, cwd=cwd, timeout_sec=timeout_sec
        )

    def render_instruction(self, instruction: str) -> str:
        """Render the instruction through the prompt template, if configured."""
        if self._prompt_template_path:
            return render_prompt_template(self._prompt_template_path, instruction)
        return instruction

    @abstractmethod
    def install_spec(self) -> AgentInstallSpec:
        """Declarative install steps executed at setup and inlined into Dockerfile builds."""

    async def install(self, environment: BaseEnvironment) -> None:
        """Run each step from :meth:`install_spec` with matching privilege."""
        for step in self.install_spec().steps:
            if step.user == "root":
                await self.exec_as_root(environment, command=step.run, env=step.env)
            else:
                await self.exec_as_agent(environment, command=step.run, env=step.env)

    async def setup(self, environment: BaseEnvironment) -> None:
        await environment.exec(command="mkdir -p /installed-agent", user="root")

        setup_dir = self.logs_dir / "setup"
        setup_dir.mkdir(parents=True, exist_ok=True)

        install_spec = environment.agent_install_spec
        is_preinstalled = (
            install_spec is not None and install_spec.agent_name == self.name()
        )
        if not is_preinstalled:
            try:
                await self.install(environment)
            except RuntimeError:
                raise
            except Exception as exc:
                raise RuntimeError(f"Agent install failed: {exc}") from exc

        if self._version is None:
            version_cmd = self.get_version_command()
            if version_cmd:
                try:
                    version_result = await environment.exec(command=version_cmd)
                    if version_result.return_code == 0 and version_result.stdout:
                        self._version = self.parse_version(version_result.stdout)
                except Exception:
                    pass  # Version detection is best-effort
